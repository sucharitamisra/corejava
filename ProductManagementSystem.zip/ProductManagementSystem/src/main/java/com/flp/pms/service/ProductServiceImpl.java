package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductServiceImpl implements IProductService {

	private IProductDao iProductDao = new ProductDaoImplForMap();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Supplier> getAllSupplier() {
		return iProductDao.getAllSuppliers();
	}

	public List<Discount> getAllDiscounts() {

		return iProductDao.getAllDiscounts();
	}

	public void addProduct(Product product) {
		Map<Integer, Product> maps = iProductDao.getAllProducts();
		boolean flag = false;
		Set<Integer> product_IDS = maps.keySet();
		int product_id_generated = generateProductId();

		// Generate unique Product Id
		if (!maps.isEmpty()) {
			do {

				product_id_generated = generateProductId();
				for (Integer product_Id : product_IDS) {
					if (product_Id == product_id_generated) {
						flag = true;
						break;
					}
				}
			} while (flag);

		}
		product.setProductId(product_id_generated);

		iProductDao.addProduct(product);
	}

	public int generateProductId() {
		return (int) (Math.random() * 10000);
	}

	public Map<Integer, Product> getAllProducts() {

		return iProductDao.getAllProducts();
	}

	public List<Product> getAllProductsList() {
		Collection<Product> collectionProduct = getAllProducts().values();
		List<Product> listProducts = new ArrayList<>();
		for (Product product : collectionProduct)
			listProducts.add(product);
		return listProducts;
	}

	public Product searchByProductName(String productName) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getProductName().equalsIgnoreCase(productName)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	public Product searchBySupplierName(String supplierName) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getSupplier().getFirstName().equalsIgnoreCase(supplierName)
					|| product.getSupplier().getLastName().equalsIgnoreCase(supplierName)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	@Override
	public Product searchByCategoryName(String categoryName) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getCategory().getCategory_Name().equalsIgnoreCase(categoryName)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	@Override
	public Product searchBySubCategoryName(String subCategoryName) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getSubCategory().getSub_category_Name().equalsIgnoreCase(subCategoryName)) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	@Override
	public Product searchByRating(float rating) {
		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getRatings() == rating) {
				searchedProduct = product;
			}
		}
		return searchedProduct;
	}

	public boolean removeProduct(int productId) {
		List<Product> products = getAllProductsList();
		Map<Integer, Product> searchedProduct = getAllProducts();
		for (Product product : products) {
			if (product.getProductId() == productId) {
		
				if (searchedProduct.remove(product.getProductId(), product))
					return true;
			}
		}
		return false;

	}

	@Override
	public Product searchProductId(int productId) {

		List<Product> products = getAllProductsList();
		Product searchedProduct = null;
		for (Product product : products) {
			if (product.getProductId() == productId) {
				searchedProduct = product;
			}
		}
		return searchedProduct;

	}

	@Override
	public Map<Integer, Product> updateProductName(Product p, String pName) {
		Map<Integer, Product> map = getAllProducts();
		p.setProductName(pName);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;

	}

	@Override
	public Map<Integer, Product> updateProductMaxRetailPrice(Product p, double max) {
		Map<Integer, Product> map = getAllProducts();
		p.setMax_retail_price(max);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;

	}

	@Override
	public Map<Integer, Product> updateProductExpDate(Product p, Date expiryD) {
		Map<Integer, Product> map = getAllProducts();
		p.setExpiry_date(expiryD);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	@Override
	public Map<Integer, Product> updateProductRating(Product p, float rating) {
		Map<Integer, Product> map = getAllProducts();
		p.setRatings(rating);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;
	}

	@Override
	public Map<Integer, Product> updateProductCategory(Product p, Category category) {
		Map<Integer, Product> map = getAllProducts();
		p.setCategory(category);
		map.put(p.getProductId(), p);
		System.out.println("Successfully Updated");
		return map;

	}
}
